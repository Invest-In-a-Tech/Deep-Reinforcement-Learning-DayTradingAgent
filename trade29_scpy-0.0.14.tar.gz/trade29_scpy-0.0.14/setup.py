from setuptools import setup

setup(name='trade29_scpy',
      version='0.0.14',
      description='Sierra Chart / python library',
      license='MIT',
      package_dir={'trade29':'src/trade29', 'trade29.sc' : 'src/trade29/sc'},
      packages=['trade29', 'trade29.sc'],
      install_requires=['pandas', 'pywin32', 'fastavro'],
      zip_safe=False
)

