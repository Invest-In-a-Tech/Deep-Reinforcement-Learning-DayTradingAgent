from io import StringIO
import pandas as pd
import re
import json
from io import BytesIO
import fastavro

from .avro import avro_msgs

class GraphDataRequest:


    def __init__(self, 
                 request_id, key, base_data, sg_data, historical_init_bars,
        realtime_update_bars, on_bar_close, update_frequency,
        include_vbp, vbp_include_empty_price_levels, include_historical_market_depth, block):

        self.msg_id = 'MsgGetChartData_S'
        self.request_id = request_id
        self.key = key
        self.base_data = base_data
        self.sg_data = sg_data
        self.historical_init_bars = historical_init_bars
        self.realtime_update_bars = realtime_update_bars
        self.on_bar_close = on_bar_close
        self.update_frequency = update_frequency
        self.include_vbp = include_vbp
        self.vbp_include_empty_price_levels = vbp_include_empty_price_levels
        self.include_historical_market_depth = include_historical_market_depth
        self.block = block

    def format_msg(self):

        base_data = ';'.join(str(i) for i in self.base_data)

        msg = {
            'id' : self.request_id,
            'key': self.key,
            'sgs': self.sg_data,
            'basedata': base_data,
            'n_hist_bars': self.historical_init_bars,
            'n_update_bars': self.realtime_update_bars,
            'on_bar_close': self.on_bar_close,
            'update_freq': self.update_frequency,
            'include_vbp': self.include_vbp,
            'vbp_include_empty_price_level': self.vbp_include_empty_price_levels,
            'historical_market_depth': self.include_historical_market_depth
        }

        return msg

    def parse_response(self, response):
        return GraphDataResponse(self, response)
    
class GraphDataResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response
        self.df = pd.read_csv(StringIO(self._response), sep=',', header=None)

        
        if request.include_vbp == True:

            # convert the vbp to list of tuples
        
            def func(x):
                n = x.split(',')   
                levels = int(len(n)/5) # assumed 5 per level: price, bidvolume, askvolume,totalvolume, numberoftrades
                return [(float(n[x*5]), int(n[x*5+1]), int(n[x*5+2]), int(n[x*5+3]), int(n[x*5+4])) for x in range(levels)] # create list of tuple vbp data (price, volume)
        
            last = len(self.df.columns)-1

            self.df[last] = self.df.apply(lambda row : func(row[last]), axis=1)


    @property
    def request_id(self):
        return self._request.request_id

class MarketDepthRequest():
        def __init__(self, request_id, key, number_of_levels, include_pulling_stacking, include_mbo, update_frequency):

            self.msg_id = 'MsgMarketDepth_S'
            self.request_id = request_id
            self.key = key
            self.number_of_levels = number_of_levels
            self.include_pulling_stacking = include_pulling_stacking
            self.include_mbo = include_mbo
            self.update_frequency = update_frequency
        
        def format_msg(self):

            msg = {
                'id': self.request_id,
                'key': self.key,
                'NLevels': self.number_of_levels,
                'IncPLST': self.include_pulling_stacking,
                'IncMBO': self.include_mbo,
                'UpdateFrequencyMS': self.update_frequency
            }
            
            return msg
        
        def parse_response(self, response):
            return MarketDepthResponse(self, response)

class MarketDepthResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response
        self.df = None
        self.parse_response(response)

    def parse_response(self, response):
            
            # df columns - 'Side', 'Price', 'BidVolume', 'AskVolume', 'BidPullinkStacking', 'AskPullingStacking', 'MBO'

            tmp = re.split('\n,+\n', response) 
            asks = tmp[0]
            bids = tmp[1]

            mbo_start = 4 # mbo starts after aks volume (we insert 2 columns to the response data we get, side and volume)
            if self._request.include_pulling_stacking == True:
                 mbo_start += 2

            asks = asks.split('\n')
            for i in range(len(asks)):
                asks[i] = asks[i].split(',')
                asks[i].insert(0, 'Ask')
                asks[i].insert(2, 0)
                if self._request.include_mbo == True:
                    asks[i] = asks[i][:mbo_start] + [[x for x in asks[i][mbo_start:] if x]]

            asks_df = pd.DataFrame(asks)

            bids = bids.split('\n')
            for i in range(len(bids)):
                bids[i] = bids[i].split(',')
                bids[i].insert(0, 'Bid')
                bids[i].insert(3, 0) # inserted ask volume is 0
                # the mbo is aggregated into a list while removing empty cells
                # the empty cells are sent from SC
                if self._request.include_mbo == True: 
                    bids[i] = bids[i][:mbo_start] + [[x for x in bids[i][mbo_start:] if x]]

            bids_df = pd.DataFrame(bids)

            self.df = pd.concat([asks_df, bids_df])

            # init the columns
            columns = ['Side', 'Price', 'BidVolume', 'AskVolume']

            if self._request.include_pulling_stacking == True:
                 columns += ['BidPullinkStacking', 'AskPullingStacking']

            if self._request.include_mbo == True:
                columns.append('MBO')

            self.df.columns = columns
    @property
    def request_id(self):
        return self._request.request_id

class SubmitOrderRequest():
    def __init__(self, request_id, key, is_buy, order_type, 
                tif, qty = 1, price1 = 0, price2 = 0, attach_orders_sc_trade_window = 0,
                ocos=None,
                block=True):

        self.msg_id = 'MsgSubmitOrder_S'
        self.request_id = request_id
        self.key = key
        self.is_buy = is_buy
        self.order_type = order_type
        self.tif = tif
        self.qty = qty
        self.price1 = price1
        self.price2 = price2
        self.attach_orders_sc_trade_window = attach_orders_sc_trade_window
        self.ocos = ocos
        self.block = block


    def format_msg(self):
        
        msg = {
            'id': self.request_id,
            'key': self.key,
            'IsBuy': self.is_buy,
            'OrderType': self.order_type,
            'TiF': self.tif,
            'Qty': self.qty,
            'Price1': self.price1,
            'Price2': self.price2,
            'AttachFromSCTW': self.attach_orders_sc_trade_window,
            'OCOs' : self.ocos
        }
        
        
        return msg
    
    def parse_response(self, response):
        return SubmitOrderResponse(self, response)

class SubmitOrderResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        self.order_id = self._response.split(',')[0]

    def __repr__(self):
        return f'order_id: {self.order_id}'
    
    def __str__(self):
        return f'order_id: {self.order_id}'

    @property
    def request_id(self):
        return self._request.request_id

class TimeAndSalesSnapshotRequest():
        def __init__(self, request_id, key, number_of_levels):

            self.msg_id = 'MsgTnSSnapshot_S'
            self.request_id = request_id
            self.key = key
            self.number_of_levels = number_of_levels
        
        def format_msg(self):

            msg = {
                'id': self.request_id,
                'key': self.key,
                'NRecords': self.number_of_levels
            }
            
            return msg

        def parse_response(self, response):
            return TimeAndSalesSnapshotResponse(self, response)
        
class TimeAndSalesSnapshotResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response
        
        self.df = pd.read_csv(StringIO(self._response), sep=',', header=None)
        self.df[0] = pd.to_datetime(self.df[0])
        self.df.columns = ['DateTime', 'Price', 'Volume', 'Type', 'Bid', 'BidSize', 'Ask', 'AskSize']
    
    @property
    def request_id(self):
        return self._request.request_id
    
class TimeAndSalesRequest():
        def __init__(self, request_id, key):
            self.msg_id = 'MsgTnSContinuous_S'
            self.request_id = request_id
            self.key = key
        
        def format_msg(self):
            
            msg ={'id' : self.request_id, 'key' : self.key}
            return msg

            
        def parse_response(self, response):
            return TimeAndSalesResponse(self, response)

class TimeAndSalesResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        self.df = pd.DataFrame.from_dict(response['TimeAndSales'])
        self.df['DateTime'] = pd.to_datetime(self.df['DateTime'], unit='us')
        


    @property
    def request_id(self):
        return self._request.request_id
    
class FlattenAndCancelRequest():
        def __init__(self, request_id, key):

            self.msg_id = 'MsgFlattenAndCancel_S'
            self.request_id = request_id
            self.key = key
        
        def format_msg(self):

            msg = {'id': self.request_id, 'key': self.key}
            
            return msg

        def parse_response(self, response):
            return FlattenAndCancelResponse(self, response)

class FlattenAndCancelResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
class CancelOrderRequest():
        def __init__(self, request_id, key, order_id):

            self.msg_id = 'MsgCancelOrder_S'
            self.request_id = request_id
            self.key = key
            self.order_id = order_id
        
        def format_msg(self):

            msg = {
                'id': self.request_id,
                'key': self.key,
                'OrderID': self.order_id
            }
            
            return msg

        def parse_response(self, response):
            return CancelOrderResponse(self, response)

class CancelOrderResponse():

    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
class ModifyOrderRequest():
        def __init__(self, request_id, key, order_id, price1, price2, qty):

            self.msg_id = 'MsgModifyOrder_S'
            self.request_id = request_id
            self.key = key
            self.order_id = order_id
            self.price1 = price1
            self.price2 = price2
            self.qty = qty
        
        def format_msg(self):

            msg = {
                'id': self.request_id,
                'key': self.key,
                'OrderID': self.order_id,
                'Price1': self.price1,
                'Price2': self.price2,
                'Qty': self.qty
            }
            
            return msg

        def parse_response(self, response):
            return ModifyOrderResponse(self, response)

class ModifyOrderResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id

class OrderStatusRequest():
        def __init__(self, request_id, key, order_id):

            self.msg_id = 'MsgOrderUpdate_S'
            self.request_id = request_id
            self.key = key
            self.order_id = order_id
        
        def format_msg(self):

            msg = {
                'id': self.request_id,
                'key': self.key,
                'OrderID': self.order_id,
            }
            
            return msg

        def parse_response(self, response):
            return OrderStatusResponse(self, response)

class OrderStatusResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return self._response

class AccountUpdateRequest():
        def __init__(self, request_id, key, subscribe, update_frequency):

            self.msg_id = 'MsgAccountStatus_S'
            self.request_id = request_id
            self.key = key
            self.subscribe = subscribe
            self.update_frequency = update_frequency
        
        def format_msg(self):

            msg = {
                'id': self.request_id,
                'key': self.key,
                'Subscribe': self.subscribe,
                'UpdateFreq': self.update_frequency
            }
            
            return msg

        def parse_response(self, response):
            return AccountUpdateResponse(self, response)

class AccountUpdateResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        tmp = response.split(',')

        '''
        0 - tadf.m_TradeAccount.GetChars(),
        1 - (int)tadf.m_IsSimulated,
        2 - tadf.m_CurrencyCode.GetChars(),
        3 - DM(tadf.m_CurrentCashBalance, -1),
        4 - (int)tadf.m_TransactionIdentifierForCashBalanceAdjustment,
        5 - DM(tadf.m_AvailableFundsForNewPositions, -1),
        6 - DM(tadf.m_MarginRequirement, -1),
        7 - DM(tadf.m_MarginRequirementFull, -1),
        8 - DM(tadf.m_MarginRequirementFullPositionsOnly, -1),
        9 - DM(tadf.m_PeakMarginRequirement, -1),
        10 - DM(tadf.m_AccountValue, -1),
        11 - DM(tadf.m_OpenPositionsProfitLoss, -1),
        12 - DM(tadf.m_DailyProfitLoss, -1),
        13 - DM(tadf.m_CalculatedDailyNetLossLimitInAccountCurrency, -1),
        14 - DM(tadf.m_TrailingAccountValueAtWhichToNotAllowNewPositions, -1),
        15 - (int)tadf.m_DailyNetLossLimitHasBeenReached,
        16 - (int)tadf.m_IsUnderRequiredMargin,
        17 - (int)tadf.m_IsUnderRequiredAccountValue,
        18 - (int)tadf.m_TradingIsDisabled,
        19 - (int)tadf.m_ClosePositionsAtEndOfDay,
        20 - tadf.m_Description.GetChars());
        '''

        self.trade_account = tmp[0]
        self.is_simulated = bool(tmp[1])
        self.currency_code = tmp[2]
        self.cash_balance = float(tmp[3])
        self.available_funds = float(tmp[5])
        self.account_value = float(tmp[10])
        self.open_positions_pnl = float(tmp[11])
        self.daily_pnl = float(tmp[12])

        self.dict = dict((key, value) for key, value in self.__dict__.items() if not callable(value) and not key.startswith('_'))

    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):

        return str(self.dict)


class PositionUpdateRequest():
        def __init__(self, request_id, key, subscribe, update_on_qty_changes, update_on_open_pnl_changes):

            self.msg_id = 'MsgPositionStatus_S'
            self.request_id = request_id
            self.key = key
            self.subscribe = subscribe
            self.update_on_qty_changes = update_on_qty_changes
            self.update_on_open_pnl_changes = update_on_open_pnl_changes
        
        def format_msg(self):
            
            msg = {
                'id': self.request_id,
                'key': self.key,
                'Subscribe': self.subscribe,
                'UpdateOnQtyChanges': self.update_on_qty_changes,
                'UpdateOnPnLChanges': self.update_on_open_pnl_changes
            }
            
            return msg

        def parse_response(self, response):
            return PositionUpdateResponse(self, response)

class PositionUpdateResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        tmp = self._response.split(',')

        self.qty = float(tmp[0])
        self.avg_price = float(tmp[1])
        self.open_pnl = float(tmp[2])

        self.dict = dict((key, value) for key, value in self.__dict__.items() if not callable(value) and not key.startswith('_'))
    
    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return f'qty: {self.qty}, avg_price: {self.avg_price}, open_pnl: {self.open_pnl}'
      

class TradeListRequest():
        def __init__(self, request_id, key):

            self.msg_id = 'MsgGetFlatToFlatTradeList_S'
            self.request_id = request_id
            self.key = key
        
        def format_msg(self):

            msg = {
                'id': self.request_id,
                'key': self.key
            }
            
            return msg

        def parse_response(self, response):
            return TradeListResponse(self, response)

class TradeListResponse():
    '''
    https://www.sierrachart.com/index.php?page=doc/TradeActivityLog.php#TradesTabFieldsDescriptions
    OpenDateTime
    CloseDateTime
    TradeType
    TradeQuantity
    MaxClosedQuantity
    MaxOpenQuantity
    EntryPrice
    ExitPrice
    TradeProfitLoss
    MaximumOpenPositionLoss
    MaximumOpenPositionProfit
    FlatToFlatMaximumOpenPositionProfit
    FlatToFlatMaximumOpenPositionLoss
    Commission
    IsTradeClosed
    Note
    '''
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return self._response

class FilledOrdersRequest():
        
        def __init__(self, request_id, key):

            self.msg_id = 'MsgGetFills_S'
            self.request_id = request_id
            self.key = key
        
        def format_msg(self):

            msg = {
                'id': self.request_id,
                'key': self.key
            }
            
            return msg

        def parse_response(self, response):
            return FilledOrdersResponse(self, response)

class FilledOrdersResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return self._response


class ConnectionInfoRequest():
        def __init__(self, request_id):

            self.msg_id = 'MsgGetConnectionInfo_S'
            self.request_id = request_id
        
        def format_msg(self):
            msg = {'id': self.request_id}

            return msg

        def parse_response(self, response):
            return ConnectionInfoResponse(self, response)

class ConnectionInfoResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        self.sc_version = response['SCVersion']
        self.scdx_version =  response['StudyVersion']
        self.connection = response['ConnectionName']
        self.chart_keys = response['Keys']

        self.dict = dict((key, value) for key, value in self.__dict__.items() if not callable(value) and not key.startswith('_'))
    
    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return f'sc_version: {self.sc_version}, scdx_version {self.scdx_version}, connection: {self.connection}, keys: {",".join(self.chart_keys)}'