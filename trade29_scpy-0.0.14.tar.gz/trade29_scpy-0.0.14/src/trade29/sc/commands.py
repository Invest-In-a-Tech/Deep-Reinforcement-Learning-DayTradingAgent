from io import StringIO
import pandas as pd
import re
import json

class GraphDataRequest:


    def __init__(self, request_id, key, base_data, sg_data, include_timestamp, historical_init_bars,
        realtime_update_bars, on_bar_close, update_frequency, include_bar_closed_status, include_bar_index, 
        include_vbp, vbp_include_empty_price_levels, block):

        self.cmd = 'S9'
        self.request_id = request_id
        self.key = key
        self.base_data = base_data
        self.sg_data = sg_data
        self.include_timestamp = include_timestamp
        self.historical_init_bars = historical_init_bars
        self.realtime_update_bars = realtime_update_bars
        self.on_bar_close = on_bar_close
        self.update_frequency = update_frequency
        self.include_bar_closed_status = include_bar_closed_status
        self.include_bar_index = include_bar_index
        self.include_vbp = include_vbp
        self.vbp_include_empty_price_levels = vbp_include_empty_price_levels
        self.block = block


    def format_msg(self):

        base_data = ';'.join(str(i) for i in self.base_data)

        msg = str.encode('{},{},{},{},{},{},{},{},{},{},{},{},{},{}\n'.format(
            self.cmd, self.request_id, self.key, self.sg_data, base_data, int(self.include_timestamp), self.historical_init_bars, 
            self.realtime_update_bars, int(self.on_bar_close), 
            self.update_frequency, int(self.include_bar_closed_status), int(self.include_bar_index),
            int(self.include_vbp), int(self.vbp_include_empty_price_levels)))
    
        return msg

    def parse_response(self, response):
        return GraphDataResponse(self, response)
    
class GraphDataResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response
        self.df = pd.read_csv(StringIO(self._response), sep=',', header=None)

        
        if request.include_vbp == True:

            # convert the vbp to list of tuples
        
            def func(x):
                if pd.isna(x):
                    return x
                
                n = x.split(',')   
                levels = int(len(n)/5) # assumed 5 per level: price, bidvolume, askvolume,totalvolume, numberoftrades
                return [(float(n[x*5]), int(n[x*5+1]), int(n[x*5+2]), int(n[x*5+3]), int(n[x*5+4])) for x in range(levels)] # create list of tuple vbp data (price, volume)
        
            last = len(self.df.columns)-1

            self.df[last] = self.df.apply(lambda row : func(row[last]), axis=1)


    @property
    def request_id(self):
        return self._request.request_id

class MarketDepthRequest():
        def __init__(self, request_id, key, number_of_levels, include_pulling_stacking, include_mbo, update_frequency):

            self.cmd = 'S10'
            self.request_id = request_id
            self.key = key
            self.number_of_levels = number_of_levels
            self.include_pulling_stacking = include_pulling_stacking
            self.include_mbo = include_mbo
            self.update_frequency = update_frequency
        
        def format_msg(self):

            msg = str.encode('{},{},{},{},{},{},{}\n'.format(self.cmd, 
                                                  self.request_id, 
                                                  self.key, 
                                                  self.number_of_levels, 
                                                  int(self.include_pulling_stacking), 
                                                  int(self.include_mbo),
                                                  self.update_frequency))

            return msg
        
        def parse_response(self, response):
            return MarketDepthResponse(self, response)

class MarketDepthResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response
        self.df = None
        self.parse_response(response)

    def parse_response(self, response):
            
            # df columns - 'Side', 'Price', 'BidVolume', 'AskVolume', 'BidPullinkStacking', 'AskPullingStacking', 'MBO'

            tmp = re.split('\n,+\n', response) 
            asks = tmp[0]
            bids = tmp[1]

            mbo_start = 4 # mbo starts after aks volume (we insert 2 columns to the response data we get, side and volume)
            if self._request.include_pulling_stacking == True:
                 mbo_start += 2

            asks = asks.split('\n')
            for i in range(len(asks)):
                asks[i] = asks[i].split(',')
                asks[i].insert(0, 'Ask')
                asks[i].insert(2, 0)
                if self._request.include_mbo == True:
                    asks[i] = asks[i][:mbo_start] + [[x for x in asks[i][mbo_start:] if x]]

            asks_df = pd.DataFrame(asks)

            bids = bids.split('\n')
            for i in range(len(bids)):
                bids[i] = bids[i].split(',')
                bids[i].insert(0, 'Bid')
                bids[i].insert(3, 0) # inserted ask volume is 0
                # the mbo is aggregated into a list while removing empty cells
                # the empty cells are sent from SC
                if self._request.include_mbo == True: 
                    bids[i] = bids[i][:mbo_start] + [[x for x in bids[i][mbo_start:] if x]]

            bids_df = pd.DataFrame(bids)

            self.df = pd.concat([asks_df, bids_df])

            # init the columns
            columns = ['Side', 'Price', 'BidVolume', 'AskVolume']

            if self._request.include_pulling_stacking == True:
                 columns += ['BidPullinkStacking', 'AskPullingStacking']

            if self._request.include_mbo == True:
                columns.append('MBO')

            self.df.columns = columns
    @property
    def request_id(self):
        return self._request.request_id

class SubmitOrderRequest():
    def __init__(self, request_id, key, is_buy, order_type, 
                tif, qty = 1, price1 = 0, price2 = 0, attach_orders_sc_trade_window = 0,
                target_enabled = False, 
                target_price = 0.0, 
                target_offset=0,
                stop_enabled = False,
                stop_price = 0.0,
                stop_offset=0.0,
                block=True):

        self.cmd = 'S12'
        self.request_id = request_id
        self.key = key
        self.is_buy = is_buy
        self.order_type = order_type
        self.tif = tif
        self.qty = qty
        self.price1 = price1
        self.price2 = price2
        self.attach_orders_sc_trade_window = attach_orders_sc_trade_window
        self.target_enabled = target_enabled
        self.target_price = target_price
        self.target_offset=target_offset
        self.stop_enabled = stop_enabled
        self.stop_price = stop_price
        self.stop_offset=stop_offset
        self.block = block


    def format_msg(self):
        msg =  str.encode('{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}\n'.format(
            self.cmd, self.request_id, self.key, int(self.is_buy), 
            self.order_type, self.tif, self.qty, self.price1, self.price2, int(self.attach_orders_sc_trade_window),
            int(self.target_enabled), self.target_price, self.target_offset, 
            int(self.stop_enabled), self.stop_price, self.stop_offset))
    
        return msg
    
    def parse_response(self, response):
        return SubmitOrderResponse(self, response)

class SubmitOrderResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        self.order_id = self._response.split(',')[0]

    def __repr__(self):
        return f'order_id: {self.order_id}'
    
    def __str__(self):
        return f'order_id: {self.order_id}'

    @property
    def request_id(self):
        return self._request.request_id

class TimeAndSalesSnapshotRequest():
        def __init__(self, request_id, key, number_of_levels):

            self.cmd = 'S4'
            self.request_id = request_id
            self.key = key
            self.number_of_levels = number_of_levels
        
        def format_msg(self):

            msg = str.encode('{},{},{},{}\n'.format(self.cmd, 
                                                  self.request_id, 
                                                  self.key, 
                                                  self.number_of_levels))

            return msg

        def parse_response(self, response):
            return TimeAndSalesSnapshotResponse(self, response)
        
class TimeAndSalesSnapshotResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response
        
        self.df = pd.read_csv(StringIO(self._response), sep=',', header=None)
        self.df[0] = pd.to_datetime(self.df[0])
        self.df.columns = ['DateTime', 'Price', 'Volume', 'Type', 'Bid', 'BidSize', 'Ask', 'AskSize']
    
    @property
    def request_id(self):
        return self._request.request_id
    
class TimeAndSalesRequest():
        def __init__(self, request_id, key):

            self.cmd = 'S8'
            self.request_id = request_id
            self.key = key
        
        def format_msg(self):

            msg = str.encode('{},{},{}\n'.format(self.cmd, 
                                                  self.request_id, 
                                                  self.key))

            return msg

        def parse_response(self, response):
            return TimeAndSalesResponse(self, response)

class TimeAndSalesResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response
        
        self.df = pd.read_csv(StringIO(self._response), sep=',', header=None)
        self.df[0] = pd.to_datetime(self.df[0])
        self.df.columns = ['DateTime', 'Price', 'Volume', 'Type', 'Bid', 'BidSize', 'Ask', 'AskSize']


    @property
    def request_id(self):
        return self._request.request_id
    
class FlattenAndCancelRequest():
        def __init__(self, request_id, key):

            self.cmd = 'D3'
            self.request_id = request_id
            self.key = key
        
        def format_msg(self):

            msg = str.encode('{},{},{}\n'.format(self.cmd, 
                                              self.request_id, 
                                              self.key))

            return msg

        def parse_response(self, response):
            return FlattenAndCancelResponse(self, response)

class FlattenAndCancelResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
class CancelOrderRequest():
        def __init__(self, request_id, key, order_id):

            self.cmd = 'D4'
            self.request_id = request_id
            self.key = key
            self.order_id = order_id
        
        def format_msg(self):

            msg = str.encode('{},{},{},{}\n'.format(self.cmd, 
                                              self.request_id, 
                                              self.key,
                                              self.order_id))

            return msg

        def parse_response(self, response):
            return CancelOrderResponse(self, response)

class CancelOrderResponse():

    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
class ModifyOrderRequest():
        def __init__(self, request_id, key, order_id, price1, price2, qty):

            self.cmd = 'D5'
            self.request_id = request_id
            self.key = key
            self.order_id = order_id
            self.price1 = price1
            self.price2 = price2
            self.qty = qty
        
        def format_msg(self):

            msg = str.encode('{},{},{},{},{},{},{}\n'.format(self.cmd, 
                                              self.request_id, 
                                              self.key,
                                              self.order_id,
                                              self.price1,
                                              self.price2,
                                              self.qty))

            return msg

        def parse_response(self, response):
            return ModifyOrderResponse(self, response)

class ModifyOrderResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id

class OrderStatusRequest():
        def __init__(self, request_id, key, order_id):

            self.cmd = 'S18'
            self.request_id = request_id
            self.key = key
            self.order_id = order_id
        
        def format_msg(self):

            msg = str.encode('{},{},{},{}\n'.format(self.cmd, 
                                              self.request_id, 
                                              self.key,
                                              self.order_id))

            return msg

        def parse_response(self, response):
            return OrderStatusResponse(self, response)

class OrderStatusResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return self._response

class AccountUpdateRequest():
        def __init__(self, request_id, key, subscribe, update_frequency):

            self.cmd = 'S19'
            self.request_id = request_id
            self.key = key
            self.subscribe = subscribe
            self.update_frequency = update_frequency
        
        def format_msg(self):

            msg = str.encode('{},{},{},{},{}\n'.format(self.cmd, 
                                              self.request_id, 
                                              self.key,
                                              int(self.subscribe),
                                              self.update_frequency))

            return msg

        def parse_response(self, response):
            return AccountUpdateResponse(self, response)

class AccountUpdateResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        tmp = response.split(',')

        '''
        0 - tadf.m_TradeAccount.GetChars(),
        1 - (int)tadf.m_IsSimulated,
        2 - tadf.m_CurrencyCode.GetChars(),
        3 - DM(tadf.m_CurrentCashBalance, -1),
        4 - (int)tadf.m_TransactionIdentifierForCashBalanceAdjustment,
        5 - DM(tadf.m_AvailableFundsForNewPositions, -1),
        6 - DM(tadf.m_MarginRequirement, -1),
        7 - DM(tadf.m_MarginRequirementFull, -1),
        8 - DM(tadf.m_MarginRequirementFullPositionsOnly, -1),
        9 - DM(tadf.m_PeakMarginRequirement, -1),
        10 - DM(tadf.m_AccountValue, -1),
        11 - DM(tadf.m_OpenPositionsProfitLoss, -1),
        12 - DM(tadf.m_DailyProfitLoss, -1),
        13 - DM(tadf.m_CalculatedDailyNetLossLimitInAccountCurrency, -1),
        14 - DM(tadf.m_TrailingAccountValueAtWhichToNotAllowNewPositions, -1),
        15 - (int)tadf.m_DailyNetLossLimitHasBeenReached,
        16 - (int)tadf.m_IsUnderRequiredMargin,
        17 - (int)tadf.m_IsUnderRequiredAccountValue,
        18 - (int)tadf.m_TradingIsDisabled,
        19 - (int)tadf.m_ClosePositionsAtEndOfDay,
        20 - tadf.m_Description.GetChars());
        '''

        self.trade_account = tmp[0]
        self.is_simulated = bool(tmp[1])
        self.currency_code = tmp[2]
        self.cash_balance = float(tmp[3])
        self.available_funds = float(tmp[5])
        self.account_value = float(tmp[10])
        self.open_positions_pnl = float(tmp[11])
        self.daily_pnl = float(tmp[12])

        self.dict = dict((key, value) for key, value in self.__dict__.items() if not callable(value) and not key.startswith('_'))

    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):

        return str(self.dict)


class PositionUpdateRequest():
        def __init__(self, request_id, key, subscribe, update_on_qty_changes, update_on_open_pnl_changes):

            self.cmd = 'S20'
            self.request_id = request_id
            self.key = key
            self.subscribe = subscribe
            self.update_on_qty_changes = update_on_qty_changes
            self.update_on_open_pnl_changes = update_on_open_pnl_changes
        
        def format_msg(self):

            msg = str.encode('{},{},{},{},{},{}\n'.format(self.cmd, 
                                              self.request_id, 
                                              self.key,
                                              int(self.subscribe),
                                              int(self.update_on_qty_changes),
                                              int(self.update_on_open_pnl_changes)))

            return msg

        def parse_response(self, response):
            return PositionUpdateResponse(self, response)

class PositionUpdateResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        tmp = self._response.split(',')

        self.qty = float(tmp[0])
        self.avg_price = float(tmp[1])
        self.open_pnl = float(tmp[2])

        self.dict = dict((key, value) for key, value in self.__dict__.items() if not callable(value) and not key.startswith('_'))
    
    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return f'qty: {self.qty}, avg_price: {self.avg_price}, open_pnl: {self.open_pnl}'
      

class TradeListRequest():
        def __init__(self, request_id, key):

            self.cmd = 'S21'
            self.request_id = request_id
            self.key = key
        
        def format_msg(self):

            msg = str.encode('{},{},{}\n'.format(self.cmd, 
                                              self.request_id, 
                                              self.key))

            return msg

        def parse_response(self, response):
            return TradeListResponse(self, response)

class TradeListResponse():
    '''
    https://www.sierrachart.com/index.php?page=doc/TradeActivityLog.php#TradesTabFieldsDescriptions
    OpenDateTime
    CloseDateTime
    TradeType
    TradeQuantity
    MaxClosedQuantity
    MaxOpenQuantity
    EntryPrice
    ExitPrice
    TradeProfitLoss
    MaximumOpenPositionLoss
    MaximumOpenPositionProfit
    FlatToFlatMaximumOpenPositionProfit
    FlatToFlatMaximumOpenPositionLoss
    Commission
    IsTradeClosed
    Note
    '''
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return self._response

class FilledOrdersRequest():
        
        def __init__(self, request_id, key):

            self.cmd = 'S22'
            self.request_id = request_id
            self.key = key
        
        def format_msg(self):

            msg = str.encode('{},{},{}\n'.format(self.cmd, 
                                              self.request_id, 
                                              self.key))

            return msg

        def parse_response(self, response):
            return FilledOrdersResponse(self, response)

class FilledOrdersResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return self._response


class ConnectionInfoRequest():
        def __init__(self, request_id):

            self.cmd = 'S23'
            self.request_id = request_id
        
        def format_msg(self):

            msg = str.encode('{},{}\n'.format(self.cmd, 
                                              self.request_id))

            return msg

        def parse_response(self, response):
            return ConnectionInfoResponse(self, response)

class ConnectionInfoResponse():
    def __init__(self, request, response):
        self._request = request
        self._response = response

        tmp = self._response.split(',')

        self.sc_version = int(tmp[0])
        self.scdx_version = int(tmp[1])
        self.connection = tmp[2]

        self.chart_keys = [x for x in tmp[3::]]


        self.dict = dict((key, value) for key, value in self.__dict__.items() if not callable(value) and not key.startswith('_'))
    
    @property
    def request_id(self):
        return self._request.request_id
    
    def __str__(self):
        return f'sc_version: {self.sc_version}, scdx_version {self.scdx_version}, connection: {self.connection}, keys: {",".join(self.chart_keys)}'