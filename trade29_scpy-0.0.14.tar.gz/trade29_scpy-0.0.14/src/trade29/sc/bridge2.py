import win32pipe, win32file
from threading import Thread
from threading import Lock
import time
import pywintypes
import winerror
from multiprocessing import Queue
from datetime import datetime

from . import commands2
from io import BytesIO
import struct

import fastavro

from .avro import avro_msgs
   
def process_requests(handle, queue, request_list, lock):

    while True:
        cmd = queue.get()
        with lock:
            request_list[cmd.request_id] = cmd

        
        data = cmd.format_msg()
        bytes_writer = bytes_writer = BytesIO()
        s_index, s_schema = avro_msgs.get_schema_details_by_name(cmd.msg_id)
        fastavro.schemaless_writer(bytes_writer, s_schema, data)

        bytes_header = BytesIO()
        bytes_header.write(struct.pack("i", 0x7F335501))
        bytes_header.write(struct.pack("i", s_index))
        bytes_header.write(struct.pack("i", bytes_writer.getbuffer().nbytes))

        win32file.WriteFile(handle, bytes_header.getbuffer())
        win32file.WriteFile(handle, bytes_writer.getbuffer())


        
def process_responses(handle, queue, queue_sync, request_list, lock):

    buff = ''
    count = 0

    while True:
        try:
            result, data = win32file.ReadFile(handle, 512*1024)
        except pywintypes.error as e:
            if e.args[0] == winerror.ERROR_NO_DATA:
                time.sleep(0.1)
                # print(e)
                continue
            
            print(e)
            raise e            
        
        print(f"message {result}/{len(data)}")

        bytes_parse = BytesIO()
        bytes_parse.write(data)
        
        bytes_parse.seek(0)
        if len(data) != 12: # stupid check for a header
            print("not a header Header")
            # throw an exception

        header = struct.unpack('iii', data)
        if header[0] != 2134070529:
            print('bad signature')
            # throw exception

        schema_idx = header[1]
        body_len = header[2]

        print(f'message length {body_len}')

        # lookup the schema
            
        # read the body
        result, data = win32file.ReadFile(handle, 64*1024)

        bytes_parse = BytesIO()
        bytes_parse.write(data)
        bytes_parse.seek(0)

        record = fastavro.schemaless_reader(bytes_parse, avro_msgs.schemas[schema_idx])

        # print(f"message: {record}")

        request_id = record['RequestID']

        resp_obj = None
        with lock:
            resp_obj = (request_list[request_id]).parse_response(record)

            # if block is set, place the respone in the sync queue. This is used for blocking calls
            # otherwise put onto the response queue, the user code will pick it up from there
            if hasattr(request_list[request_id], 'block') and request_list[request_id].block == True:
                queue_sync.put_nowait(resp_obj)
            else:
                queue.put_nowait(resp_obj)
                
class SCBridge():
    def __init__(self, run=True, connection=None):
        self.send_queue = None
        self.receive_queue = None
        self.receive_queue_sync = None
        self.next_id = 1000
        self.request_list = {}
        self.lock = None
        self.send_thread = None
        self.receive_thread = None
        self.running = False
        self.connection = 't29scdxavro' if connection == None else connection

        if run == True:
            self.run()    

    def _get_next_id(self):
        self.next_id += 1
        return self.next_id
    
    
    def get_response_queue(self):
        return self.receive_queue
    
    def time_and_sales_request(self, key=''):

        request_id = self._get_next_id()

        request = commands2.TimeAndSalesRequest(request_id, key)
        self.send_queue.put_nowait(request)

        return request.request_id

    def time_and_sales_snapshot_request(self, key='', number_of_levels = 10):

        request_id = self._get_next_id()

        request = commands2.TimeAndSalesSnapshotRequest(request_id, key, number_of_levels)
        self.send_queue.put_nowait(request)

        return request.request_id
    
    def submit_order(self, key = '', 
                     is_buy = False, 
                     order_type = 0, 
                     tif = 0, 
                     qty = 1, 
                     price1 = 0, 
                     price2 = 0,
                     attach_orders_sc_trade_window = False, 
                     ocos=None,
                     block=True):

        request_id = self._get_next_id()

        request = commands2.SubmitOrderRequest(request_id, 
                                    key, 
                                    is_buy,
                                    order_type, 
                                    tif, 
                                    qty, 
                                    price1, 
                                    price2, 
                                    attach_orders_sc_trade_window,
                                    ocos,
                                    block)

        
        self.send_queue.put_nowait(request)
        
        
        if request.block:
            ret = self.receive_queue_sync.get()
        else:
            ret = request.request_id 

        return ret
    
    def market_depth_request(self, key='', number_of_levels = 5, include_pulling_stacking = False, update_frequency = 0, include_mbo=False):

        request_id = self._get_next_id()

        request = commands2.MarketDepthRequest(request_id, key, number_of_levels, include_pulling_stacking, include_mbo, update_frequency)
        self.send_queue.put_nowait(request)

        return request.request_id

    def graph_data_request(self, key='', base_data = '', sg_data = '', historical_init_bars = 0,
        realtime_update_bars  = 1, on_bar_close = False, update_frequency = 5000, 
        include_vbp=False, vbp_include_empty_price_levels=False, include_historical_market_depth=False, block=False):
    

        request_id = self._get_next_id()

        request = commands2.GraphDataRequest(
            request_id, key, base_data, sg_data, historical_init_bars,
            realtime_update_bars, on_bar_close, update_frequency, include_vbp, 
            vbp_include_empty_price_levels, include_historical_market_depth, block)
        
        self.send_queue.put_nowait(request)


        if request.block:
            ret = self.receive_queue_sync.get()
        else:
            ret = request.request_id 

        return ret
  
    
    def flatten_and_cancel(self, key):
        request_id = self._get_next_id()

        request = commands2.FlattenAndCancelRequest(request_id, key)
        
        self.send_queue.put_nowait(request)

        return request.request_id
    
    def cancel_order(self, key, order_id):
        request_id = self._get_next_id()

        request = commands2.CancelOrderRequest(request_id, key, order_id)
        
        self.send_queue.put_nowait(request)

        return request.request_id
    
    def modify_order(self, key, order_id, price1=0.0, price2=0.0, qty=0):
        request_id = self._get_next_id()

        request = commands2.ModifyOrderRequest(request_id, key, order_id, price1, price2, qty)
        
        self.send_queue.put_nowait(request)

        return request.request_id
    
    
    def get_order_status(self, key, order_id):
        request_id = self._get_next_id()

        request = commands2.OrderStatusRequest(request_id, key, order_id)
        
        self.send_queue.put_nowait(request)

        return request.request_id

    def get_position_status(self, key, subscribe=False, update_on_qty_changes=True, update_on_open_pnl_changes=True):
        request_id = self._get_next_id()

        request = commands2.PositionUpdateRequest(request_id, key, subscribe, update_on_qty_changes, update_on_open_pnl_changes)
        
        self.send_queue.put_nowait(request)

        return request.request_id
    
    def get_account_status(self, key, subscribe=True, update_frequency=5000):
        request_id = self._get_next_id()

        request = commands2.AccountUpdateRequest(request_id, key, subscribe, update_frequency)
        
        self.send_queue.put_nowait(request)

        return request.request_id

    def get_trade_list(self, key):
        request_id = self._get_next_id()

        request = commands2.TradeListRequest(request_id, key)
        
        self.send_queue.put_nowait(request)

        return request.request_id

    def get_filled_orders(self, key):
        request_id = self._get_next_id()

        request = commands2.FilledOrdersRequest(request_id, key)
        
        self.send_queue.put_nowait(request)

        return request.request_id

    def get_connection_info(self):
        request_id = self._get_next_id()

        request = commands2.ConnectionInfoRequest(request_id)
        
        self.send_queue.put_nowait(request)

        return request.request_id
    
    def run(self):

        print(f'running bridge v0.0.14--------{datetime.now().strftime("%Y/%m/%d %H:%M:%S")}')

        print('connecting to sc')
        handle = win32file.CreateFile('\\\\.\\pipe\\' + self.connection,
            win32file.GENERIC_READ | win32file.GENERIC_WRITE,
            0,
            None,
            win32file.OPEN_EXISTING,
            0,
            None)

        res = win32pipe.SetNamedPipeHandleState(handle, win32pipe.PIPE_READMODE_MESSAGE | win32pipe.PIPE_NOWAIT, None, None)
        if res == 0:
            print(f"SetNamedPipeHandleState return code: {res}")

        self.lock = Lock()

        print('starting receiver')
        self.receive_queue = Queue(1000)
        self.receive_queue_sync = Queue(10)
        self.receive_thread = Thread(target=process_responses, args=(handle, self.receive_queue, self.receive_queue_sync, self.request_list, self.lock), daemon=True, name='receiver thread')
        self.receive_thread.start()

        print('starting sender')
        self.send_queue = Queue(1000)
        self.send_thread = Thread(target=process_requests, args=(handle, self.send_queue, self.request_list, self.lock), daemon=True, name='cmd thread')
        self.send_thread.start()

        self.running = True

        
        request_id = self._get_next_id()
        request = commands2.ConnectionInfoRequest(request_id)
        self.send_queue.put_nowait(request)

        msg = self.get_response_queue().get()

        print(f'sc_version {msg.sc_version}')
        print(f'scdx_version {msg.scdx_version}')
        print(f'connection {msg.connection}')
        print(f'chart_keys {",".join(msg.chart_keys)}')
        


def run():
    bridge = SCBridge()
    bridge.run()

    return bridge




